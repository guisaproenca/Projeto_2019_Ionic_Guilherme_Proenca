export interface user {
    email: string
    username: string
    first_name: string
    last_name: string
    password: string
}

export interface login{
    username: string
    password: string
    token: string
}

export interface infoPiu{
    id: number,
    favoritado: boolean,
    conteudo: string,
    data: Date,
    usuario: any,
}

export interface usu{
    username: string,
    password: string,
    token: string
}