import { Component } from '@angular/core';
import { NavController, IonicPage } from 'ionic-angular';
import { CadastroPage } from '../cadastro/cadastro';
import { login } from '../../modelos/modelos'
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { FeedPage } from '../feed/feed'
import { HomePage } from '../home/home';
import { Storage } from '@ionic/storage';
import { Observable } from 'rxjs/Observable';


@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  constructor(public navCtrl: NavController, private _http: HttpClient, private _storage: Storage) {

  }

  prox_pag(){
    this.navCtrl.push(CadastroPage)
  }
  
  public usuario: string= ""
  public senha: string= ""
  public tok: string=""

  pagfeed(){
    this.navCtrl.push(HomePage)
  }

  salva(logi: login) {
    let promise = this._storage.set("", logi);

    return Observable.fromPromise(promise);
  }
  
  login(){
    
    let logi: login = {
      username: this.usuario,
      password: this.senha,
      token: this.tok
    }

    return this._http.post("http://piupiuwer.polijunior.com.br/api/login/", JSON.stringify(logi), {
        headers: new HttpHeaders().set('Content-Type', 'application/json'),
        params: new HttpParams()
        .set("username", this.usuario)
        .set("password", this.senha)
    })
        .mergeMap(() => this.salva(logi))
        .subscribe(
          (res) => {
            logi.token = res.token
            this.pagfeed();

          },
          
          () => {
                alert("Usuário ou senha incorretos")
            }
        )
  }
}
