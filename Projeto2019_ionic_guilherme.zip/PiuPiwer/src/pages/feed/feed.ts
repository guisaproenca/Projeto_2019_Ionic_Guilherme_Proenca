import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { infoPiu } from '../../modelos/modelos';
import { HttpClient } from '@angular/common/http';


@IonicPage()
@Component({
  selector: 'page-feed',
  templateUrl: 'feed.html',
})
export class FeedPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, private _http: HttpClient ) {
  }

  public pius: infoPiu[]
  
  pegarPius(){
    return this._http.get<infoPiu[]>('http://piupiuwer.polijunior.com.br/api/pius/')
  }

  atualizaPius(){
    this.pegarPius()
      .subscribe(
        (res) => {this.pius = res,
        console.log("salve")},
        () => {alert("erro")}
     );
    
     console.log(this.pius)
 }
  
  ionViewDidLoad() {
    console.log('ionViewDidLoad FeedPage');
  

    this.atualizaPius()
    }
  }
